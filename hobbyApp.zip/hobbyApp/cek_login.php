<?php

include("koneksi.php");

if(isset($_POST["username"]) && isset($_POST["password"])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $conn->set_charset("UTF8");
    $sql = "SELECT * FROM users where username = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $username, $password);
    $stmt->execute();
    $res = $stmt->get_result();
    $array = array();

    if ($res->num_rows > 0) {
        while ($obj = $res->fetch_object())
        {
            $array[] = $obj;
        }
        echo json_encode(array("result" => "OK", "data" => $array));
    } else {
        echo json_encode(array("result" => "ERROR", "message" => "No account found."));
    }
    echo json_encode($arrayresult);
}

?>

