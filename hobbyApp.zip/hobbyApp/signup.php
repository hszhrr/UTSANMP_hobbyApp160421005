<?php

include("koneksi.php");


if (isset($_POST["username"]) && isset($_POST["nama_depan"]) && isset($_POST["nama_belakang"]) && isset($_POST["email"]) && isset($_POST["password"])) {
    $username = $_POST["username"];
    $nama_depan = $_POST["nama_depan"];
    $nama_belakang = $_POST["nama_belakang"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    $conn->set_charset("UTF8");
    $sql = "INSERT INTO users (username, nama_depan, nama_belakang, email, password) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sssss', $username, $nama_depan, $nama_belakang, $email, $password);
    $stmt->execute();
    $array = array("result" => "OK", "message" => "Data successfully inserted");
    echo json_encode($array);
    } else {
    echo json_encode(array("result" => "ERROR", "message" => "Failed to insert data")); 
    }

?>