<?php

include("koneksi.php");

if (isset($_POST["id"]) && isset($_POST["nama_depan"]) && isset($_POST["nama_belakang"]) && isset($_POST["password"])) {
    $id = $_POST["id"];
    $nama_depan = $_POST["nama_depan"];
    $nama_belakang = $_POST["nama_belakang"];
    $password = $_POST["password"];

    $conn -> set_charset("UTF8");
    $sql = "UPDATE users SET nama_depan = ?, nama_belakang = ?, password = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sssi', $nama_depan, $nama_belakang, $password, $id);
    $stmt->execute();

    $array = array("result" => "OK", "message" => "Data successfully updated");
    echo json_encode($array);
} else {
    echo json_encode(array("result" => "ERROR", "message" => "Failed to update data")); 
    }

?>