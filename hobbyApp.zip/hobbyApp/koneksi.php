<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hobbyapp_160421005";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

?>